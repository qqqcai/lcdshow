#!/bin/bash
# 系统架构信息 - System architecture information
# 可执行程序最终存放路径 - Final executable storage path
EXECUTABLE="/usr/local/bin/ldbg-linux-app"

if [ "$1" = "uninstall" ]; then
    sudo rm -f "$EXECUTABLE" "$ROOT_EXECUTABLE" /usr/share/icons/ldbg-appicon.png /usr/share/applications/ldbg-linux-app.desktop
    echo "卸载完成 - Uninstallation completed"
else
    BITNESS=$(getconf LONG_BIT)
    case "$BITNESS" in
    64)
        echo "当前系统是树莓派64位系统 - Current system is Raspberry Pi 64-bit"
        sudo cp ldbg-linux-arm64 "$EXECUTABLE"
        ;;
    32)
        echo "当前系统是树莓派32位系统 - Current system is Raspberry Pi 32-bit"
        sudo cp ldbg-linux-armhf "$EXECUTABLE"
        ;;
    *)
        echo "未知系统架构: $BITNESS - Unknown system architecture: $BITNESS"
        echo "无法确定处理方式，脚本退出 - Unable to determine processing method, script exits"
        exit 1
        ;;
    esac
    # 设置图标和桌面快捷方式文件 - Set icon and desktop shortcut file
    sudo mkdir -p /usr/share/icons
    sudo cp ldbg-appicon.png /usr/share/icons/
    sudo cp ldbg-linux-app.desktop /usr/share/applications/
    echo "安装完成 - Installation completed"
fi
